using System.Diagnostics;
using BepInEx;
using UnityEngine;

[BepInPlugin("com.yourname.supermarkettogether.healthbar", "Health Bar Mod", "1.0.0")]
public class Plugin : BaseUnityPlugin
{
    void Start()
    {
        UnityEngine.Debug.Log("SpawnHealthUI started");

        StartCoroutine(UIManager.SpawnHealthUI());
    }
}
