/*
using HarmonyLib;
using UnityEngine;

[HarmonyPatch(typeof(, "HitPlayer")]
public class BroomHitPatch
{
    static void Postfix(GameObject player)
    {
        var health = player.GetComponent<PlayerHealth>();
        if (health != null)
        {
            health.TakeDamage(10f);
        }
    }
}
*/