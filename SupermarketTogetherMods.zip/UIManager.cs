using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class UIManager : MonoBehaviour
{
    static Slider healthSlider;
    static PlayerHealth playerHealth;

    public static IEnumerator SpawnHealthUI()
    {
        Debug.Log("SpawnHealthUI started");
        yield return new WaitForSeconds(1f);

        var player = GameObject.FindWithTag("Player");
        if (player == null) yield break;

        if (player.GetComponent<PlayerHealth>() == null)
            player.AddComponent<PlayerHealth>();

        playerHealth = player.GetComponent<PlayerHealth>();

        var canvasGO = new GameObject("HealthCanvas");
        var canvas = canvasGO.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasGO.AddComponent<CanvasScaler>();
        canvasGO.AddComponent<GraphicRaycaster>();

        var sliderGO = new GameObject("HealthSlider");
        sliderGO.transform.SetParent(canvasGO.transform);
        var rt = sliderGO.AddComponent<RectTransform>();
        rt.sizeDelta = new Vector2(200, 20);
        rt.anchoredPosition = new Vector2(0, -50);
        rt.anchorMin = new Vector2(0.5f, 1);
        rt.anchorMax = new Vector2(0.5f, 1);
        rt.pivot = new Vector2(0.5f, 1);

        healthSlider = sliderGO.AddComponent<Slider>();
        healthSlider.minValue = 0;
        healthSlider.maxValue = 100f;
        healthSlider.value = 100f;

        GameObject fillGO = new GameObject("Fill");
        fillGO.transform.SetParent(sliderGO.transform);
        Image fillImage = fillGO.AddComponent<Image>();
        fillImage.color = Color.red;
        healthSlider.fillRect = fillImage.rectTransform;

        // Attach this script to a persistent GameObject to enable Update
        if (canvasGO.GetComponent<UIManager>() == null)
            canvasGO.AddComponent<UIManager>();
    }

    void Update()
    {
        if (healthSlider != null && playerHealth != null)
        {
            healthSlider.value = playerHealth.currentHealth;
        }
    }
}
