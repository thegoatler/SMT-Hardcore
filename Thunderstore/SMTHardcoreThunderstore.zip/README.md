![https://github.com/thegoatler/SMT-Hardcore/blob/main/banner.png](https://github.com/thegoatler/SMT-Hardcore/blob/master/banner.png)


# SMT-Hardcore
### A fully customizable mod that adds death and damage to Supermarket Together
Currently Implemented (Features):
- Getting hit with broom deals 10 damage
- Health Bar at top of screen
- Products not found deals damage
- Products too expensive deals damage
- Products stolen deals damage
- Deleting things in the store deals damage
- Running out of health sends to jail
- Running out of health loses money
- Probably more at some point, gotta learn how to do the rest first

Credits:
- Damntry for teaching me how to do this and implementing a good portion of the project
- Mitche for also teaching me how to do this and helping with a significant portion as well
